package com.cscorner.gentlebegins;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.Objects;

public class SummaryMedicine extends AppCompatActivity {
    private GraphView graphView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.summary_medicine);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Summary");

        graphView = findViewById(R.id.graphView);

        // Initialize Firebase and reference to your data
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("your_data_path");

        // Add a ValueEventListener to fetch and display data
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                LineGraphSeries<DataPoint> series = new LineGraphSeries<>();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    double x = Double.parseDouble(snapshot.getKey()); // Assuming keys are X values
                    double y = snapshot.getValue(Double.class); // Assuming values are Y values

                    series.appendData(new DataPoint(x, y), true, 100); // Adjust based on your needs
                }

                graphView.addSeries(series);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle errors or failures in reading data
            }
        });
    }
}
