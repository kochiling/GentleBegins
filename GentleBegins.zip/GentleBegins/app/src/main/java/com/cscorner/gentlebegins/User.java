package com.cscorner.gentlebegins;

public class User {

    String feedingdate,foodnotess,foodtypess,timess;

    public String getFeedingdate() {
        return feedingdate;
    }
    public String getFoodnotess() {
        return foodnotess;
    }

    public String getFoodtypess() {
        return foodtypess;
    }

    public String getTimess() {
        return timess;
    }

}
